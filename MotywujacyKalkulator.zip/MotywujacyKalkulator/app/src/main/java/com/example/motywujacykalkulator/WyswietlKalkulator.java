package com.example.motywujacykalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class WyswietlKalkulator extends AppCompatActivity {
    double liczba1, liczba2, wynik;
    char znakBufor = '0';
    boolean reset = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wyswietl_kalkulator);
    }

    public void klikLiczba(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        String liczba=textview.getText().toString();
        if(reset){
            oknoText.setText("");
            reset = false;
        }
        oknoText.setText(oknoText.getText()+liczba);
    }

    public void klikDzialanie(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        String znak=textview.getText().toString();
        if(reset){
            return;
        }
        switch (znak){
            case "/":
                znakBufor = '/';
                break;
            case "*":
                znakBufor = '*';
                break;
            case "+":
                znakBufor = '+';
                break;
            case "-":
                znakBufor = '-';
                break;
        }
        if(oknoText.getText()==""){
            return;
        }
        liczba1 = Double.parseDouble(oknoText.getText().toString());
        oknoText.setText("");
    }

    public void klikEq(View view) {
        if(reset){
            return;
        }
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        if(oknoText.getText()==""){
            return;
        }
        liczba2 = Double.parseDouble(oknoText.getText().toString());
        oknoText.setText("");

        switch (znakBufor){
            case '0':
                return;
            case '/':
                wynik = liczba1/liczba2;
                break;
            case '*':
                wynik = liczba1*liczba2;
                break;
            case '+':
                wynik = liczba1+liczba2;
                break;
            case '-':
                wynik = liczba1-liczba2;
                break;
        }
        String wyswietl = Double.toString(liczba1) +" "+ znakBufor +" "+
                Double.toString(liczba2) + " = " + Double.toString(wynik);
        oknoText.setText(wyswietl);
        znakBufor = '0';
        reset = true;
    }
    public void klikKropka(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        if(reset){
            oknoText.setText("0.");
            reset = false;
            return;
        }
        if(oknoText.getText()==""){
            oknoText.setText("0");
        }
        oknoText.setText(oknoText.getText()+".");
    }

    public void klikC(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk

        oknoText.setText("");
        znakBufor='0';
    }
}