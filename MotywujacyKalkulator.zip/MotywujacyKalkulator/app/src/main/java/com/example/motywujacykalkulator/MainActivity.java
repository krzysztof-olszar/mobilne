package com.example.motywujacykalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int[] poprzednie = new int[]{0, 0};
    int[] listaStr = new int[]{R.string.af1,R.string.af2,R.string.af3,R.string.af4,
            R.string.af5,R.string.af6,R.string.af7,R.string.af8,R.string.af9,R.string.af10};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /** Called when the user taps the Aforyzm button */
    public void sendAforyzm(View view) {
        // Do something in response to button
        int x;
        do{
            x = (int)(Math.random()*10+1);
        }while(x==poprzednie[0] || x==poprzednie[1]);
        poprzednie[0]=poprzednie[1];
        poprzednie[1]=x;
        TextView tv = (TextView)findViewById(R.id.textView);
        int afor = listaStr[x-1];
        tv.setText(afor);
    }

    public void otworzKalkulator(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, WyswietlKalkulator.class);
        startActivity(intent);
    }
}