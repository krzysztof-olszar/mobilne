package com.example.motywujacykalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class WyswietlKalkulator extends AppCompatActivity {
    double liczba1, liczba2, wynik;
    char znakBufor = '0';
    boolean reset = true;
    double pamiec = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wyswietl_kalkulator);
    }

    public void klikLiczba(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        String liczba=textview.getText().toString();
        if(reset){
            oknoText.setText("");
            reset = false;
        }
        oknoText.setText(oknoText.getText()+liczba);
    }

    public void klikDzialanie(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        String znak=textview.getText().toString();
        if(reset){
            return;
        }
        switch (znak){
            case "/":
                znakBufor = '/';
                break;
            case "*":
                znakBufor = '*';
                break;
            case "+":
                znakBufor = '+';
                break;
            case "-":
                znakBufor = '-';
                break;
            case "^":
                znakBufor = '^';
                break;
        }
        if(oknoText.getText()==""){
            return;
        }
        liczba1 = Double.parseDouble(oknoText.getText().toString());
        oknoText.setText("");
    }

    public void klikEq(View view) {
        if(reset){
            return;
        }
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        if(oknoText.getText()==""){
            return;
        }
        liczba2 = Double.parseDouble(oknoText.getText().toString());
        oknoText.setText("");

        switch (znakBufor){
            case '0':
                return;
            case '/':
                wynik = liczba1/liczba2;
                break;
            case '*':
                wynik = liczba1*liczba2;
                break;
            case '+':
                wynik = liczba1+liczba2;
                break;
            case '-':
                wynik = liczba1-liczba2;
                break;
            case '^':
                wynik = Math.pow(liczba1,liczba2);
                break;
        }
        String wyswietl = Double.toString(liczba1) +" "+ znakBufor +" "+
                Double.toString(liczba2) + " = " + Double.toString(wynik);
        oknoText.setText(wyswietl);
        znakBufor = '0';
        reset = true;
    }
    public void klikKropka(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        if(reset){
            oknoText.setText("0.");
            reset = false;
            return;
        }
        if(oknoText.getText()==""){
            oknoText.setText("0");
        }
        oknoText.setText(oknoText.getText()+".");
    }

    public void klikC(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk

        oknoText.setText("");
        znakBufor='0';
    }
    public double factorial(double x){
        int wynik=1;
        for(int i=1;i<=x;i++){
            wynik *= i;
        }
        return wynik;
    }

    public void klikOperacja(View view) {
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        String znak=textview.getText().toString();
        double liczba = Double.parseDouble(oknoText.getText().toString());
        if(reset){
            return;
        }
        String wyswietl = "blad";
        switch (znak){
            case "√":
                wyswietl = Double.toString(Math.sqrt(liczba));
                break;
            case "!":
                wyswietl = Double.toString(factorial(liczba));
                break;
            case "Sin":
                wyswietl = Double.toString(Math.sin(liczba));
                break;
            case "Cos":
                wyswietl = Double.toString(Math.cos(liczba));
                break;
            case "Tg":
                wyswietl = Double.toString(Math.tan(liczba));
                break;
            case "log":
                wyswietl = Double.toString(Math.log10(liczba));
                break;
        }

        oknoText.setText(wyswietl);
        znakBufor = '0';
        reset = true;
    }

    public void klikDodajPamiec(View view){
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        pamiec = Double.parseDouble(oknoText.getText().toString());
    }

    public void klikWczytajPamiec(View view){
        if(reset){
            return;
        }
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        oknoText.setText(Double.toString(pamiec));
    }

    public void klikProcent(View view) {
        if(reset){
            return;
        }
        TextView oknoText = (TextView)findViewById(R.id.okno);
        TextView textview = (TextView) view;//klikniety przycisk
        if(oknoText.getText()==""){
            return;
        }
        liczba2 = Double.parseDouble(oknoText.getText().toString());
        oknoText.setText("");

        switch (znakBufor){
            case '0':
                return;
            case '/':
                wynik = liczba1/(liczba2/100);
                break;
            case '*':
                wynik = liczba1*(liczba2/100);
                break;
            case '+':
                wynik = liczba1+(liczba2/100);
                break;
            case '-':
                wynik = liczba1-(liczba2/100);
                break;
            case '^':
                wynik = Math.pow(liczba1,(liczba2/100));
                break;
        }
        String wyswietl = Double.toString(liczba1) +" "+ znakBufor +" "+
                Double.toString(liczba2) + "% = " + Double.toString(wynik);
        oknoText.setText(wyswietl);
        znakBufor = '0';
        reset = true;
    }
}